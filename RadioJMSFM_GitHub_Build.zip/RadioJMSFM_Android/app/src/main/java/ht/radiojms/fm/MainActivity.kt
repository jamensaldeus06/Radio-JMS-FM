package ht.radiojms.fm

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors

const val RADIO_STREAM_URL = "https://stream.zeno.fm/9p58mseutkevv"
private val Blue = Color(0xFF082B78)
private val Yellow = Color(0xFFFFDA22)

class MainActivity : ComponentActivity() {
    private var controller by mutableStateOf<MediaController?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, RadioPlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try { controller = future.get() } catch (_: Exception) { controller = null }
        }, MoreExecutors.directExecutor())

        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Yellow, onPrimary = Blue,
                background = Blue, surface = Color(0xFF102F70)
            )) {
                var playing by remember { mutableStateOf(false) }
                RadioHome(
                    isPlaying = playing,
                    onPlayPause = {
                        controller?.let { c ->
                            if (playing) c.pause() else c.play()
                            playing = !playing
                        }
                    }
                )
            }
        }
    }

    override fun onDestroy() {
        controller?.release()
        controller = null
        super.onDestroy()
    }
}

@Composable
fun RadioHome(isPlaying: Boolean, onPlayPause: () -> Unit) {
    val context = LocalContext.current
    fun openWhatsApp(number: String) {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$number"))
        context.startActivity(intent)
    }

    Column(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF17469A), Blue)))
            .padding(horizontal = 24.dp, vertical = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(14.dp))
            androidx.compose.foundation.Image(
                painter = painterResource(R.drawable.radio_jms_logo),
                contentDescription = "Logo RADIO JMS FM",
                modifier = Modifier.size(170.dp).clip(RoundedCornerShape(22.dp)),
                contentScale = ContentScale.Fit
            )
            Spacer(Modifier.height(16.dp))
            Text("RADIO JMS FM", color = Color.White, fontSize = 29.sp,
                fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text("89.1 FM", color = Yellow, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text("La radio qui nous rassemble !", color = Color.White,
                fontSize = 14.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(24.dp))
            Surface(color = Color(0xFF3A1717), shape = RoundedCornerShape(50.dp)) {
                Row(Modifier.padding(horizontal = 18.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(9.dp).background(Color.Red, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text("EN DIRECT", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("Vous écoutez", color = Color(0xFFDCE6FF), fontSize = 15.sp)
            Text("RADIO JMS FM", color = Color.White, fontSize = 21.sp,
                fontWeight = FontWeight.Bold)
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Button(
                onClick = onPlayPause,
                modifier = Modifier.size(88.dp),
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(containerColor = Yellow, contentColor = Blue)
            ) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (isPlaying) "Pause" else "Écouter",
                    modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(10.dp))
            Text(if (isPlaying) "RADIO EN COURS" else "APPUYEZ POUR ÉCOUTER",
                color = Color.White, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(22.dp))
            Text("CONTACTEZ-NOUS SUR WHATSAPP", color = Yellow,
                fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { openWhatsApp("50944471825") },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                    Text("4447-1825")
                }
                OutlinedButton(onClick = { openWhatsApp("50943880204") },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                    Text("4388-0204")
                }
            }
            Spacer(Modifier.height(12.dp))
            Text("Haïti • RADIO JMS FM", color = Yellow, fontSize = 12.sp)
        }
    }
}
