# RADIO JMS FM 89.1 — projet Android

Projet source d’application Android native pour la radio en direct.

- Nom : RADIO JMS FM 89.1
- Slogan : La radio qui nous rassemble !
- Flux : https://stream.zeno.fm/9p58mseutkevv
- WhatsApp : +509 4447-1825 et +509 4388-0204
- Identifiant Android : ht.radiojms.fm
- Lecture audio en arrière-plan via AndroidX Media3 MediaSessionService.

## Créer et tester l’APK
1. Sur un ordinateur, installer Android Studio récent avec Android SDK 35.
2. Décompresser ce ZIP et ouvrir le dossier `RadioJMSFM_Android` dans Android Studio.
3. Laisser Gradle télécharger les plugins et bibliothèques (connexion Internet requise).
4. Tester sur un téléphone Android connecté ou un émulateur.
5. Pour créer un APK : **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## État
Ce ZIP contient le code source Android corrigé, pas un APK compilé. Cet environnement ne possède pas Android SDK/Gradle, donc je ne peux pas confirmer une compilation APK ici. Il faudra compiler et tester dans Android Studio avant distribution.
